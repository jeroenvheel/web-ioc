﻿using System.Threading.Tasks;
using Autofac;
using Autofac.Core;
using Microsoft.AspNet.SignalR;
using web_ioc.Models;

namespace web_ioc.Hubs
{
    public class TestHub : Hub
    {
        private readonly ISessionStore _store;
        private readonly ILifetimeScope _scope;

        public TestHub(ISessionStore store, ILifetimeScope lifetimeScope)
        {
            _store = store;
            _scope = lifetimeScope;
        }

        public void activate()
        {
            //var s = _scope.Resolve<ISessionModel>();
            var id = new System.Guid(this.Context.RequestCookies["iocHub"].Value);
            var session = _store.Get(id);
            //var cc = _scope.Resolve<ISessionBasesClass>(new ResolvedParameter((pi, ctx) => { return pi.ParameterType == typeof(ISessionModel) && pi.Name == "session"; }, (pi, ctx) => { return session; }));
            Clients.Caller.Activated();
        }
    }
}