﻿using System.Web.Mvc;
using web_ioc.components;
using web_ioc.Models;

namespace web_ioc.Controllers
{
    public class HomeController : Controller
    {
        private ISessionModel _session;

        public HomeController(ISessionModel session)
        {
            _session = session;
            var aa = new Class1();
        }

        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";

            _session.Value = true;
            var cookie = new System.Web.HttpCookie("iocHUB", $"{_session.Id}") { Secure = false, Shareable = false, HttpOnly = true, SameSite = System.Web.SameSiteMode.Strict, Path = "/" };
            this.Response.Cookies.Add(cookie);


            return View();
        }

        public ActionResult Logoff()
        {
            Session.Abandon();

            return View("Index");
        }
    }
}
