﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace web_ioc.Models
{
    public class SessionStore : ISessionStore
    {
        private readonly Dictionary<Guid, ISessionModel> _store = new Dictionary<Guid, ISessionModel>();

        public SessionStore()
        {
        }

        public ISessionModel Get(Guid id)
        {
            return _store[id];
        }

        public void Set(ISessionModel session)
        {
            this._store[session.Id] = session;
        }
    }
}