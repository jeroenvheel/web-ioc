﻿using System;

namespace web_ioc.components
{
    public class Class1
    {
    }
}
